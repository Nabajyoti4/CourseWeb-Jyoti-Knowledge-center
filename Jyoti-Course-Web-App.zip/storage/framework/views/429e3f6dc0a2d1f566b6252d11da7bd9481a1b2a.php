
<?php $__env->startSection('title'); ?>
    Student Form Two Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>


    <!-- Search -->
    <form class="d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="" method="GET">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="text" class="form-control border-2 small" name="coupon" placeholder="Search for..."
                   aria-label="Search" aria-describedby="basic-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search fa-sm"></i>
                </button>
            </div>
        </div>
    </form>


    <hr>
    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="usersTable">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Student Details</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Date</th>
                        <th>Show Details</th>
                    </tr>
                    </thead>
                    <tbody id="data">
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->created_at->diffForHumans()); ?></td>
                            <td><a href="<?php echo e(route('admin.formthree.show', $student->id)); ?>" class="genric-btn success circle">Show</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">No data found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        setInterval(function() {
            $("#data").load(location.href+" #data>*","");
        }, 10000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Jyoti-Course-Web-App\resources\views/admin/formthree/index.blade.php ENDPATH**/ ?>