<?php $__env->startSection('title'); ?>
    Student Form details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .borderdiv {
            position: relative;
            padding: 32px;
            border-radius: 10px;
            border: 2px solid #75b3e2;
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .header {
            position: absolute;
            top: -14px;
            left: 1%;
            padding: 0% 2px;
            margin: 0%;
            background: white !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>


    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="usersTable">
        <div id="colorlib-contact">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-md-offset-1 animate-box">
                        <h3>Admission application form</h3>
                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="name" class="font-weight-bold">Name of child: </label>
                                    <p><?php echo e($record->name); ?></p>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="image" class="font-weight-bold">Passport Size photo: </label>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="age" class="font-weight-bold">Age</label>
                                    <p><?php echo e($record->age); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-4">
                                    <label for="gender" class="font-weight-bold">Gender: </label>
                                    <p><?php echo e($record->gender); ?></p>
                                </div>
                            </div>


                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="father_name" class="font-weight-bold">Father's Name: </label>
                                    <p><?php echo e($record->father_name); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="father_contact_no" class="font-weight-bold">Phone No: </label>
                                    <p><?php echo e($record->father_phone); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="mother_name" class="font-weight-bold">Mother's Name: </label>
                                    <p><?php echo e($record->mother_name); ?></p>
                                </div>

                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="mother_contact_no" class="font-weight-bold">Phone No: </label>
                                    <p><?php echo e($record->mother_phone); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="emergency" class="font-weight-bold">Emergency contact and authorized pickup person: </label>
                                    <p><?php echo e($record->emergency); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="father_email" class="font-weight-bold">Email: </label>
                                    <p><?php echo e($record->email); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-6 col-sm-6">
                                    <label for="from" class="font-weight-bold">Pickup timing from: </label>
                                    <p><?php echo e($record->from); ?></p>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <label for="to" class="font-weight-bold">To: </label>
                                    <p><?php echo e($record->to); ?></p>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12">
                                    <label for="facility" class="font-weight-bold">Daycare facility started from: </label>
                                    <p><?php echo e($record->facility); ?></p>
                                </div>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        setInterval(function() {
            $("#data").load(location.href+" #data>*","");
        }, 10000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Jyoti-Course-Web-App\resources\views/admin/formfour/show.blade.php ENDPATH**/ ?>