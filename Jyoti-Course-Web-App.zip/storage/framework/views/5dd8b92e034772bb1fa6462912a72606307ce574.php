<?php $__env->startSection('title'); ?>
    Form pdf files
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="usersTable">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Pdf </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Form-one</th>
                        <th>Form-two</th>
                        <th>Form-three</th>
                        <th>Form-four</th>
                    </tr>
                    </thead>
                    <tbody id="data">
                    <?php $__empty_1 = true; $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($pdf->form_one); ?>

                                <form action="">
                                    <input type="file">
                                </form></td>
                            <td><?php echo e($pdf->form_two); ?></td>
                            <td><?php echo e($pdf->form_three); ?></td>
                            <td><?php echo e($pdf->form_four); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td>
                                <form action="">
                                    <input type="file" name="form-one">
                                </form></td>
                            <td>
                                <form action="">
                                    <input type="file" name="form-one">
                                </form></td>
                            <td>
                                <form action="">
                                    <input type="file" name="form-one">
                                </form></td>
                            <td>
                                <form action="">
                                    <input type="file" name="form-one">
                                </form></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        setInterval(function() {
            $("#data").load(location.href+" #data>*","");
        }, 10000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Jyoti-Course-Web-App\resources\views/admin/pdf/index.blade.php ENDPATH**/ ?>