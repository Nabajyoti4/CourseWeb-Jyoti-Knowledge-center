<?php $__env->startSection('title'); ?>
    Courses
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>

    <a class="genric-btn success circle" href="<?php echo e(route('admin.courses.create')); ?>"><i class="fas fa-user-edit"></i>
        Create New Course
    </a>

    <hr>
    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="usersTable">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Courses</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Course title</th>
                        <th>Cover</th>
                        <th>Form</th>
                        <th>Edit</th>
                    </tr>
                    </thead>
                    <tbody id="data">
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($course->title); ?></td>
                            <td><img style="height: 200px; width: 200px; background-size: cover;" alt="" src="<?php echo e(asset('storage/'.$course->image)); ?>"></td>
                            <td><a href="<?php echo e(asset('storage/'.$course->form)); ?>" target="_blank">Pdf Form</a></td>
                            <td><a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="genric-btn success circle">Edit</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">No data found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        setInterval(function() {
            $("#data").load(location.href+" #data>*","");
        }, 10000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Jyoti-Course-Web-App\resources\views/admin/course/index.blade.php ENDPATH**/ ?>